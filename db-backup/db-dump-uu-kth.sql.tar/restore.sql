--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Debian 13.2-1.pgdg100+1)
-- Dumped by pg_dump version 13.2 (Debian 13.2-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "asv-postgrest";
--
-- Name: asv-postgrest; Type: DATABASE; Schema: -; Owner: asv
--

CREATE DATABASE "asv-postgrest" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE "asv-postgrest" OWNER TO asv;

\connect -reuse-previous=on "dbname='asv-postgrest'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: asv; Type: TABLE DATA; Schema: public; Owner: asv
--

COPY public.asv (pid, asv_id, asv_sequence) FROM stdin;
\.
COPY public.asv (pid, asv_id, asv_sequence) FROM '$$PATH$$/3070.dat';

--
-- Data for Name: dataset; Type: TABLE DATA; Schema: public; Owner: asv
--

COPY public.dataset (pid, dataset_id, filename, insertion_time, in_bioatlas, bioatlas_resource_uid) FROM stdin;
\.
COPY public.dataset (pid, dataset_id, filename, insertion_time, in_bioatlas, bioatlas_resource_uid) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: sampling_event; Type: TABLE DATA; Schema: public; Owner: asv
--

COPY public.sampling_event (pid, material_sample_id, dataset_pid, event_date, sampling_protocol, sample_size_value, location_id, decimal_latitude, decimal_longitude, geodetic_datum, coordinate_uncertainty_in_meters, event_id_alias, recorded_by, verbatim_locality, municipality, country, minimum_elevation_in_meters, maximum_elevation_in_meters, minimum_depth_in_meters, maximum_depth_in_meters) FROM stdin;
\.
COPY public.sampling_event (pid, material_sample_id, dataset_pid, event_date, sampling_protocol, sample_size_value, location_id, decimal_latitude, decimal_longitude, geodetic_datum, coordinate_uncertainty_in_meters, event_id_alias, recorded_by, verbatim_locality, municipality, country, minimum_elevation_in_meters, maximum_elevation_in_meters, minimum_depth_in_meters, maximum_depth_in_meters) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: emof; Type: TABLE DATA; Schema: public; Owner: asv
--

COPY public.emof (pid, measurement_type, measurement_type_id, measurement_value, measurement_value_id, measurement_unit, measurement_unit_id, measurement_accuracy, measurement_remarks, event_pid, measurement_determined_date, measurement_determined_by, measurement_method) FROM stdin;
\.
COPY public.emof (pid, measurement_type, measurement_type_id, measurement_value, measurement_value_id, measurement_unit, measurement_unit_id, measurement_accuracy, measurement_remarks, event_pid, measurement_determined_date, measurement_determined_by, measurement_method) FROM '$$PATH$$/3068.dat';

--
-- Data for Name: mixs; Type: TABLE DATA; Schema: public; Owner: asv
--

COPY public.mixs (pid, sop, target_gene, target_subfragment, lib_layout, pcr_primer_name_forward, pcr_primer_name_reverse, pcr_primer_forward, pcr_primer_reverse, env_broad_scale, env_local_scale, env_medium) FROM stdin;
\.
COPY public.mixs (pid, sop, target_gene, target_subfragment, lib_layout, pcr_primer_name_forward, pcr_primer_name_reverse, pcr_primer_forward, pcr_primer_reverse, env_broad_scale, env_local_scale, env_medium) FROM '$$PATH$$/3066.dat';

--
-- Data for Name: occurrence; Type: TABLE DATA; Schema: public; Owner: asv
--

COPY public.occurrence (pid, event_pid, asv_pid, organism_quantity, previous_identifications, asv_id_alias, associated_sequences) FROM stdin;
\.
COPY public.occurrence (pid, event_pid, asv_pid, organism_quantity, previous_identifications, asv_id_alias, associated_sequences) FROM '$$PATH$$/3072.dat';

--
-- Data for Name: taxon_annotation; Type: TABLE DATA; Schema: public; Owner: asv
--

COPY public.taxon_annotation (pid, asv_pid, status, kingdom, phylum, class, oorder, family, genus, specific_epithet, infraspecific_epithet, otu, date_identified, identification_references, reference_db, annotation_algorithm, annotation_confidence, taxon_remarks, scientific_name, taxon_rank) FROM stdin;
\.
COPY public.taxon_annotation (pid, asv_pid, status, kingdom, phylum, class, oorder, family, genus, specific_epithet, infraspecific_epithet, otu, date_identified, identification_references, reference_db, annotation_algorithm, annotation_confidence, taxon_remarks, scientific_name, taxon_rank) FROM '$$PATH$$/3074.dat';

--
-- Name: asv_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: asv
--

SELECT pg_catalog.setval('public.asv_pid_seq', 29695, true);


--
-- Name: dataset_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: asv
--

SELECT pg_catalog.setval('public.dataset_pid_seq', 16, true);


--
-- Name: emof_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: asv
--

SELECT pg_catalog.setval('public.emof_pid_seq', 593, true);


--
-- Name: occurrence_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: asv
--

SELECT pg_catalog.setval('public.occurrence_pid_seq', 63851, true);


--
-- Name: sampling_event_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: asv
--

SELECT pg_catalog.setval('public.sampling_event_pid_seq', 580, true);


--
-- Name: taxon_annotation_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: asv
--

SELECT pg_catalog.setval('public.taxon_annotation_pid_seq', 29545, true);


--
-- PostgreSQL database dump complete
--

